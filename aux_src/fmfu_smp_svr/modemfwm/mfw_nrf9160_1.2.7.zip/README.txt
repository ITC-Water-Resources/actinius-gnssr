This release includes FOTA update from mfw_nrf9160_1.2.3 release to mfw_nrf9160_1.2.7 release.
FOTA update filename is mfw_nrf9160_update_from_1.2.3_to_1.2.7.bin.

This release includes FOTA-TEST images between mfw_nrf9160_1.2.7 release and mfw_nrf9160_1.2.7-FOTA-TEST image.
FOTA test update filenames are mfw_nrf9160_update_from_1.2.7_to_1.2.7-FOTA-TEST and mfw_nrf9160_update_from_1.2.7-FOTA-TEST_to_1.2.7.

UUID of mfw_nrf9160_1.2.7 is 20059fb4-0ad6-4128-8e96-f3d348e219c8
UUID of mfw_nrf9160_1.2.7-FOTA-TEST is fa59a46f-0681-41e6-b2b6-1d5bd7556f27